<?php
	require_once 'eKatab/eKatab.class.php';
	new eKatab("RESTful_Web_Services.epub");
?>