/*!
 *
 *  # BiB/i Extension: Zine
 *
 *  - "Zine Utility for BiB/i"
 *  - (c) Satoru MATSUSHIMA - http://bibi.epub.link or https://github.com/satorumurmur/bibi
 *  - Licensed under the MIT license. - http://www.opensource.org/licenses/mit-license.php
 *
 *  ## Components:
 *  1. BiB/i Extension: Zine (core)
 *  2. JS-YAML - http://nodeca.github.io/js-yaml/ | Copyright (c) Vitaly Puzrin - Licensed under the MIT license.
 *
 */
